
package cs475.loopMRF;

public class LoopyBP {

	private LoopMRFPotentials potentials;
	private int iterations;
	// add whatever data structures needed

	public LoopyBP(LoopMRFPotentials p, int iterations) {
		this.potentials = p;
		this.iterations = iterations;
	}

	public double[] marginalProbability(int x_i) {
		// TODO
	}

}

