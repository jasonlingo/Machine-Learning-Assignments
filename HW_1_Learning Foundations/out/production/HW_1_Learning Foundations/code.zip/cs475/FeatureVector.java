package cs475;

import java.io.Serializable;

public class FeatureVector implements Serializable {

	public void add(int index, double value) {
		// TODO Auto-generated method stub
		
	}
	
	public double get(int index) {
		// TODO Auto-generated method stub
		return 0;
	}

}
