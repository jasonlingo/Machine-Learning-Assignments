package cs475.RBM2;
import cs475.RBM2.*;

public class RBMEnergy {
	private RBMParameters parameters;
	private int num_samples;
	
	// TODO: Add the required data structures and methods.

	public RBMEnergy(RBMParameters parameters, int numSamples) {
		this.parameters = parameters;
		this.num_samples = numSamples;
	}
	
	public double computeMarginal(int j) {
		// TODO: Add code here
		return 0.0;
	}
}
